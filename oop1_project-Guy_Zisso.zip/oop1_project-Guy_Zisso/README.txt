#Game Project with SFML: Map-based Game with Player and Enemies which utilizes SFML
By Guy Zisso
ID 206553349

This project is a simple game where the player navigates through a map, moves around, drops bombs to destroy destructible walls (@), and interacts with moving enemies (!). The game is level-based, and the player wins by reaching the door (D) several times, until he reaches the final level.
This is an upgrade over the previous version, by providing a graphic interface using SFML.
In this version, the player can create the first level.

##Project Structure
```
game_project/
│
├── CMakeLists.txt        # CMake build configuration
├── main.cpp              # Main entry point of the game
├── Game.cpp              # Game logic and main game loop
├── Game.h                # Header for the Game class
├── Map.cpp               # Handles map loading and manipulation
├── Map.h                 # Header for the Map class
├── Player.cpp            # Player class for managing the player's actions
├── Player.h              # Header for the Player class
├── Enemy.cpp             # Enemy class for enemy logic
├── Enemy.h               # Header for the Enemy class
└── resources/
    └── level1.txt        # Map file for the first level
    └── level2.txt        # Map file for the second level
    ...
    └── #.png             # image of the sprite corresponding to the wall '#'
    └── @.png
    └── r.png             # images of the sprite '/', the hero.
    ...
    └── Board.txt          # If applicable, the initial map of the game
    └── Board.txt  
```
##Data Structures
A vector of Enemy objects, a 2-D vector that stores the grid/map, and the objects as described below.

##Algorithms


##Classes and Responsibilities
###Game: 
The core class that controls the game's flow, user input, and interactions. It initializes the game, runs the main game loop, and checks for victory conditions.
###Map: 
Handles the loading of the level map from a text file, rendering the map to the screen, and checking for valid player movement. It also handles the destruction of destructible walls.
###Player: 
The player's character, which can move around the map, drop bombs, and interact with the environment (e.g., destroy walls, defeat enemies).
###Enemy: 
Represents the enemies in the game. Enemies move randomly and interact with the player and the environment.
###LevelManager: 
Responsible for managing the current level, including loading the level map and transitioning between levels.
###I/O: 
Handles screen rendering and console interactions.


##Bugs/features and TODOs:
1. The enemies can eat each other and the destructable walls

##Game Mechanics
- Player Movement: The player is represented by \ and can move up, down, left, or right using the WASD keys.
- Bombs: The player can drop bombs using the B key. Bombs destroy destructible walls (@) and can defeat enemies (!).
- Enemies: Enemies are represented by !. They move randomly within the map.
- Level Completion: The player reaches the door (D) to win the level.
- Multiple Levels: The game supports multiple levels, which are loaded from text files located in the levels/ directory.


##Map Layout
The map is represented as a 2D grid where:

# are indestructible walls.
@ are destructible walls that can be destroyed by dropping bombs.
! are enemies that move randomly.
\ is the player.
D is the door that the player must reach to win the level.


##Building and Running the Game
###Prerequisites
C++ Compiler (e.g., g++, clang++).
CMake to build the project.

###Steps to Build and Run:
ENV requirments:
In case of an SFML error- 
1. Download the correct SFML- version 2.6:
brew install sfml@2
or link it if it exists: brew link --force sfml@2
check the installation path is: /opt/homebrew/Cellar/sfml@2/2.6.2/ 
which is what you'll see in the CMAKE as well.


2. Try reinstalling CommandLine tools:
sudo rm -rf /Library/Developer/CommandLineTools
xcode-select --install

export CXXFLAGS="-stdlib=libc++ -I/Library/Developer/CommandLineTools/usr/include/c++/v1"
export LDFLAGS="-lc++"
OR adding these lines to CMAKE:
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -stdlib=libc++ -I/Library/Developer/CommandLineTools/usr/include/c++/v1")
set(CMAKE_EXE_LINKER_FLAGS "${CMAKE_EXE_LINKER_FLAGS} -lc++")



Build and run:
`mkdir build`
`cd build`

`cmake ..`

`make`

`./oop_ex4`


##Controls:
W: Move up.
A: Move left.
S: Move down.
D: Move right.
B: Drop a bomb to destroy destructible walls and defeat enemies.


##How to Add New Levels
Enter the desired dimensions, and use the toolbar to create it using the sprites. 
Green button - saves the board.
Blue button - deletes everythin.
Red button - eraser. When touching a sprite will delete it.
