#include "Enemy.h"
#include "Map.h"
#include <cstdlib>
#include <ctime>



Enemy::Enemy(int x, int y) : DynamicObject(x,y), prevX(x), prevY(y) {}

void Enemy::move() {
    std::cout << "frozen = checkpoint " << std::endl;
    std::cout << "frozen = " << FreezeEnemy::frozen << std::endl;
    if (FreezeEnemy::frozen) return; 
    if (moveBack) {
        x = prevX;
        y = prevY;
    } else {
        srand(time(0));
        int dx = rand() % 3 - 1;
        int dy = rand() % 3 - 1;
        // setPosition(getX() + dx, getY() + dy);
        x += dx;
        y += dy;
    }
    moveBack = !moveBack;
}


std::vector<Enemy> Enemy::setEnemies(const Map& currentMap) {
    std::vector<Enemy> enemies;

    for (int i = 0; i < currentMap.getHeight(); ++i) {
        for (int j = 0; j < currentMap.getWidth(); ++j) {
            if (currentMap.getGrid()[i][j] == '!') {
                enemies.push_back(Enemy(i, j));  // Add a new enemy at the position of '!'
            }
        }
    }

    return enemies;  // Return the vector of enemies
}

