#include "Bomb.h"
#include "Map.h"
#include "macros.h"

#include <iostream> // delete todo arc

Bomb::Bomb() : active(false), timer(sf::seconds(2)) {}
Bomb::Bomb(int timer) : active(false), timer(sf::seconds(timer)) {}


void Bomb::activate(float x, float y) {
    if(!active){
        this->x = int(x) % TILE_SIZE > TILE_SIZE/2 ? x/50 + 1 : x/50;
        this->y = int(y) % TILE_SIZE > TILE_SIZE/2 ? y/50 + 1 : y/50;
        active = true;
        clock.restart();  // Restart the clock when the bomb is dropped
    }
}

bool Bomb::check(){
    bool exploded = false;
    
    if (clock.getElapsedTime() < timer)
        return exploded;
    else {
        exploded = active;
        active = false;
    }

    return exploded;
}

int Bomb::getX() const {
    return x;
}

int Bomb::getY() const {
    return y;
}

bool Bomb::isActive() const {
    return active;
}

sf::Clock Bomb::getClock() const{
    return clock;
}

sf::Time Bomb::getTimer() const{
    return timer;
}