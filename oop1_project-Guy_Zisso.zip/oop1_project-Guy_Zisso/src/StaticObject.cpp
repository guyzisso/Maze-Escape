#include "StaticObject.h"

StaticObject::StaticObject() : GameObject() {}

StaticObject::StaticObject(int x, int y) : GameObject(x, y) {}
