#include "DynamicObject.h"

DynamicObject::DynamicObject() : GameObject() {}

DynamicObject::DynamicObject(float x, float y) : GameObject(x,y) {}

void DynamicObject::setPosition(float x, float y) {
    this->x = x;
    this->y = y;
}
