#include "RemoveEnemy.h"
#include <cstdlib> // For rand()

RemoveEnemy::RemoveEnemy() {}

RemoveEnemy::RemoveEnemy(int x, int y, int type) : Gift(x, y, type) {}


void RemoveEnemy::activate() {  
}


void RemoveEnemy::activate(std::vector<Enemy>& enemies) {
    std::cout << "Enemy removed!" << std::endl;
    if (enemies.empty()) return;

    int index = rand() % enemies.size();
    enemies.erase(enemies.begin() + index);
}

