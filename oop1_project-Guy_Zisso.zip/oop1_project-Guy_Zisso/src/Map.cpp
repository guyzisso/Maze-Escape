#include "Map.h"
#include <fstream>
#include <iostream>
#include "macros.h"

#include <SFML/Graphics.hpp>
#include <unordered_map>


Map::Map() {}

int Map::getHeight() const {
    return height;  
}

int Map::getWidth() const {
    return width; 
}

void Map::loadLevel() {
    std::string fileName = "./Board.txt";

    std::ifstream file(fileName);

    if (!file.is_open()) {
        std::cerr << "Error: Could not open the file " << fileName << std::endl;
        return;
    }

    grid.clear();
    
    std::string line;
    while (std::getline(file, line)) {
        grid.push_back(std::vector<char>(line.begin(), line.end()));
    }


    file.close();
    height = grid.size();
    width = grid[0].size();
}


bool Map::loadLevel(int lvl) {
    std::string fileName = std::filesystem::current_path().string() + LEVELS_PATH + "level" + std::to_string(lvl) + ".txt";
    std::ifstream file(fileName);

    if (!file.is_open()) {
        std::cerr << "Error: Could not open the file " << fileName << std::endl;
        return false;
    }

    grid.clear();
    std::string line;
    while (std::getline(file, line)) {
        grid.push_back(std::vector<char>(line.begin(), line.end()));
    }

    file.close();
    height = grid.size();
    width = grid[0].size();

    return true;
}


void Map::printGrid() {
    for (const auto& row : grid) {
        for (const auto& cell : row) {
            std::cout << cell;
        }
        std::cout << '\n'; // Move to the next row
    }
}

void Map::render(sf::RenderWindow& window, Player player) {
    // std::cout << player.getX() << "," << player.getY() << std::endl;


    std::vector<char> keys = {'#', '@', '/', '!', 'g', 'b', 'D'};
    std::unordered_map<char, sf::Texture> textures;
    for (const auto& key : keys) {
    // for (const auto& [key, filePath] : textureFiles) {
        sf::Texture texture;
        std::string path = key == '/' ? "./r.png" : "./"+std::string(1, key)+".png";
        if (!texture.loadFromFile(path)) {
            std::cerr << "Error: Could not load texture from " << path << std::endl;
            return;
        }

        textures[key] = texture;
    }

    // Render the grid with sprites
    for (int i = 0; i < getHeight(); ++i) {
        for (int j = 0; j < getWidth(); ++j) {
            char tile = grid[i][j];

            sf::Sprite sprite;

            // Check if the tile has a corresponding texture
            if (textures.find(tile) != textures.end()) 
                sprite.setTexture(textures[tile]);
            else 
                continue;  // Skip rendering for unrecognized tiles
            

            // Set sprite position
            if (tile != '/'){
                sprite.setPosition(j * TILE_SIZE, i * TILE_SIZE);
            
                // Render the sprite
                window.draw(sprite);
            }
        }
    }
}


bool Map::isValidMove(float x, float y, bool right, bool down) const {
    int tileX = static_cast<int>(x/ TILE_SIZE);
    int tileY = static_cast<int>(y/ TILE_SIZE);
    bool obstacle = (right && !down && (grid[tileY][tileX+1] == '@' || grid[tileY][tileX+1] == '#')) || 
                    (down && right && (grid[tileY+1][tileX+1] == '@' || grid[tileY+1][tileX+1] == '#')) ||
                    (down && !right && (grid[tileY+1][tileX] == '@' || grid[tileY+1][tileX] == '#')) ||
                    (!right && !down && (grid[tileY][tileX] == '@' || grid[tileY][tileX] == '#'));
    
    return x >= 0 && x < width*TILE_SIZE && y >= 0 && y < height*TILE_SIZE && !obstacle;
}

bool Map::isDestructibleWall(int x, int y) const {
    return grid[y][x] == '@';
}

void Map::destroyWall(int x, int y) {
    if (isDestructibleWall(x, y)) {
        grid[y][x] = ' ';
    }
}


void Map::updateMap(Player &player, std::vector<Enemy> &enemies, std::vector<Gift*>& gifts, Game &game) {
    // Check if enough time has passed before moving enemies

    int tileX = static_cast<int>(player.getX() / TILE_SIZE);
    int tileY = static_cast<int>(player.getY() / TILE_SIZE);
    tileY += game.down ? 1 : 0;
    tileX += game.right ? 1 : 0;

    if (grid[tileY][tileX] == 'D') return;


    
    for (int i = 0; i < height; ++i) 
        for (int j = 0; j < width; ++j) 
            // if (i == tileX && j == tileY) continue;
            if (grid[i][j] == '/' || grid[i][j] == '!' || grid[i][j] == 'g') 
                grid[i][j] = ' ';


    for (auto it = gifts.begin(); it != gifts.end(); ++it) 
        grid[(*it)->getX()][(*it)->getY()] = 'g';

    for (auto it = enemies.begin(); it != enemies.end(); ++it) 
        grid[it->getX()][it->getY()] = '!'; 
        
    grid[tileY][tileX] = grid[tileY][tileX] == ' ' ? '/' : grid[tileY][tileX]; 


    if (player.bomb.isActive())
        grid[player.bomb.getY()][player.bomb.getX()] = 'b';



    if (player.bomb.check()) { //todo arc
        // Explosion logic: Affect 3x3 area around the bomb
        // std::cout << ""<<clock.getElapsedTime().asSeconds()<<" csdc" << std::endl;
        int bombX = player.bomb.getX();
        int bombY = player.bomb.getY();

        for (int dx = -1; dx <= 1; ++dx) {
            for (int dy = -1; dy <= 1; ++dy) {
                int targetX = bombX + dx;
                int targetY = bombY + dy;

                if (targetX >= 0 && targetX < width && targetY >= 0 && targetY < height) {
                    if (grid[targetY][targetX] == '/')
                        player.setPosition(1, 1);

                    if (grid[targetY][targetX] != '#' && grid[targetY][targetX] != 'D') 
                        grid[targetY][targetX] = ' ';
                    

                    // If the target is an enemy, remove it
                    for (auto it = enemies.begin(); it != enemies.end(); ++it) 
                        if (it->getX() == targetY && it->getY() == targetX) {
                            enemies.erase(it);  // Remove enemy
                            break;  
                        }
                }
            }
        }
    }

    // Decrease bomb timer if the player has dropped a bomb
    // if (player.bomb.isActive()) { //todo arc - maybe change to "whenActvated"? to delay movement
    //     player.move(0, 0);
    // } 
}


const std::vector<std::vector<char>>& Map::getGrid() const {
    return grid;
}

