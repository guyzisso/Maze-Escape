#include "AddTime.h"

AddTime::AddTime() {}

AddTime::AddTime(int x, int y, int type) : Gift(x, y, type) {}

void AddTime::activate() {

}