#include "AddLives.h"

AddLives::AddLives() {}

AddLives::AddLives(int x, int y, int type) : Gift(x, y, type) {}


void AddLives::activate() {

}