#include "Gift.h"



Gift::Gift() {}
Gift::Gift(int x, int y, int type) : StaticObject(x, y), type(type) {}


int Gift::getType() const{
    return type;
}
