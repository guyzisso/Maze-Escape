#include "FreezeEnemy.h"


bool FreezeEnemy::frozen = false;
sf::Clock FreezeEnemy::freezeClock;

FreezeEnemy::FreezeEnemy() {}

FreezeEnemy::FreezeEnemy(int x, int y, int type) : Gift(x, y, type) {}

void FreezeEnemy::activate() {
    std::cout << "Enemies frozen for 3 seconds!" << std::endl;
    frozen = true;
    freezeClock.restart();
}





