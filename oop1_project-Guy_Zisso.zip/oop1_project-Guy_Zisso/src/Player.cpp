#include "Player.h"
#include <iostream> //arc delete


Player::Player() { //TODO DynamicObject
    setPosition(1,1);
    velocity = {0.0f, 0.0f};
}

Player::Player(float x, float y) {
    setPosition(x,y);
    velocity = {0.0f, 0.0f};
}

Player::Player(float x, float y, int bombTimer) : bomb(bombTimer) {
    setPosition(x,y);
    velocity = {0.0f, 0.0f};
}


void Player::dropBomb() {

    bomb.activate(x, y);
}

void Player::move(int dx, int dy) {
    x += dx;
    y += dy;
}


void Player::update(float deltaTime, Map map, bool right, bool down) {
    float newX = x + velocity.x * SPEED * deltaTime;
    float newY = y + velocity.y * SPEED * deltaTime;

    // Check if the move is valid before updating position
    if (map.isValidMove(newX, newY, right, down)) {
        x = newX;
        y = newY;
    }

    // Ensure the player stays within the window boundaries
    // x = std::max(0.0f, std::min(x, map.getWidth() * TILE_SIZE - TILE_SIZE));
    // y = std::max(0.0f, std::min(y, map.getHeight() * TILE_SIZE - TILE_SIZE));    
}

void Player::setVelocity(float vx, float vy) {
    velocity.x = vx;
    velocity.y = vy;
}


void Player::addLife() {
    lives++;
}

void Player::removeLife() {
    if (lives > 0) lives--;
}

int Player::getLives() const {
    return lives;
}


