#include "Game.h"


namespace fs = std::filesystem;

void createMap();
int countFilesInDirectory(const std::string& path);


Game::Game() : currentLevel(1), player(new Player(1, 1)), window(sf::VideoMode(DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT), "Bomberman") {
    // Load the level to initialize currentMap
    if (!std::filesystem::exists("./Board.txt"))
        createMap();

    currentMap = new Map;
    currentMap->loadLevel();

    loadObjectsFromMap(); 

    std::string lvls_path = std::filesystem::current_path().string() + LEVELS_PATH;
    numlevels = countFilesInDirectory(lvls_path);

}


void Game::restart(){
    restartGame = true;
}

// void Game::handleInput(sf::Event event) {
//     if (event.type == sf::Event::KeyPressed) {
//         switch (event.key.code) {
//             case sf::Keyboard::W:
//                 if (currentMap->isValidMove(player->getX() - 1, player->getY())) {
//                     player->move(-1, 0);
//                 }
//                 break;
//             case sf::Keyboard::A:
//                 if (currentMap->isValidMove(player->getX(), player->getY() - 1)) {
//                     player->move(0, -1);
//                 }
//                 break;
//             case sf::Keyboard::S:
//                 if (currentMap->isValidMove(player->getX() + 1, player->getY())) {
//                     player->move(1, 0);
//                 }
//                 break;
//             case sf::Keyboard::D:
//                 if (currentMap->isValidMove(player->getX(), player->getY() + 1)) {
//                     player->move(0, 1);
//                 }
//                 break;
//             case sf::Keyboard::B:
//                 player->dropBomb();
//                 break;
//             default:
//                 break;
//         }
//     }
// }

//TODO ARC 
//sprite.setScale(2.f, 2.f);  // Doubles the size of the bounding box


void Game::handleInput(sf::Event event) {
    float vx = 0.0f, vy = 0.0f;

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {vy = -1.0f;   down  = false; }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::S)) {vy = 1.0f;    down  = true;  }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::A)) {vx = -1.0f;   right = false; }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D)) {vx = 1.0f;    right = true; }

    

    player->setVelocity(vx, vy);

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::B)) 
        player->dropBomb();
    
    
    // Reset velocity when the key is released
    // if (event.type == sf::Event::KeyReleased) {
    //     if (event.key.code == sf::Keyboard::W || event.key.code == sf::Keyboard::S) vy = 0.0f;
    //     if (event.key.code == sf::Keyboard::A || event.key.code == sf::Keyboard::D) vx = 0.0f;

    //     player->setVelocity(vx, vy);
    // }


}




void Game::run() {
    int curr_level = 0;
    Menu menu(window);
    while (window.isOpen()) {
        sf::Time deltaTime = clock.restart();
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } if (event.type == sf::Event::MouseButtonPressed &&
                event.mouseButton.button == sf::Mouse::Left) {
                sf::Vector2f mousePos = window.mapPixelToCoords(sf::Mouse::getPosition(window));
                menu.handleClick(mousePos, *this);
            } 
        }
        if (restartGame){
            curr_level = 1;
            currentMap->loadLevel(curr_level);
            loadObjectsFromMap(); 
            player->setPosition(1, 1);
            restartGame = false;
        }

        handleInput(event);  // Handle input

        player->update(deltaTime.asSeconds(), *currentMap, right, down);

        int tileX = static_cast<int>(player->getX() / TILE_SIZE);
        int tileY = static_cast<int>(player->getY() / TILE_SIZE);

        if (enemyMoveClock.getElapsedTime().asSeconds() >= moveDelay) {
            // Move the enemies
    
            // TODO ARC  - move this to game
            for (auto& enemy : enemies) {
                if (enemy.getX() == tileY && enemy.getY() == tileX) {
                    player->setPosition(1, 1); 
                    player->removeLife();
                    menu.updateLives(player->getLives());
                }
                
                enemy.move();  
    
            
                if (enemy.getX() == tileY && enemy.getY() == tileX) {
                    player->setPosition(1, 1); 
                    player->removeLife();
                    menu.updateLives(player->getLives());
                }
            }
            
            // Reset the clock after moving the enemies
            enemyMoveClock.restart();
        }

        for (auto it = gifts.begin(); it != gifts.end(); ) {
            if ((*it)->getX() == tileY && (*it)->getY() == tileX) {
                std::cout << "Gift collected. Type= " << (*it)->getType() << std::endl;
                if (auto* removeEnemyGift = dynamic_cast<RemoveEnemy*>(*it)) {
                    std::cout << "Enemy removed!" << std::endl;
                    removeEnemyGift->activate(enemies); 
                } else if (auto* addLivesGift = dynamic_cast<AddLives*>(*it)) {
                    std::cout << "Extra life added!" << std::endl;
                } else if (auto* adddadTimeGift = dynamic_cast<AddTime*>(*it)) {
                    std::cout << "Extra time added!" << std::endl;
                }
        
                delete *it;
                it = gifts.erase(it);
            } else {
                ++it;
            }
        }
        
        

        currentMap->updateMap(*player, enemies, gifts, *this); 
        
        
        if (currentMap->getGrid()[tileY][tileX] == 'D') {
            if (curr_level < numlevels) {
                curr_level++;
                currentMap->loadLevel(curr_level);
                loadObjectsFromMap(); 
                player->setPosition(1, 1);
            } else {
                std::cout << "You win!" << std::endl;
                break;
            }
        }

        // Rendering
        window.clear(sf::Color::White);//TODO ARC ask player if u want a black or white screen - add to menu
        currentMap->render(window, *player);  // Render the map using SFML
        menu.render(window);
        
        // Render player separately
        sf::Sprite playerSprite;
        sf::Texture playerTexture;
        if (!playerTexture.loadFromFile("./r.png")) {
            std::cerr << "Error loading player texture\n";
        } else {
            playerSprite.setTexture(playerTexture);    

            playerSprite.setPosition(player->getX(), player->getY());
            window.draw(playerSprite);
        }


        window.display();  



    }
}



//TODO ARC - move to resoruce manager and delete
// Functions to load the toolbar objects
std::unordered_map<char, sf::Texture> loadToolbarObjects(const std::string& filename) {
    std::unordered_map<char, sf::Texture> textures;
    std::ifstream file(filename);

    if (!file) {
        std::cerr << "Failed to open " << filename << "\n";
        return textures;
    }

    char object;
    while (file >> object) {
        sf::Texture texture;
        std::string path = object == '/' ? "./r.png" : "./" + std::string(1, object) + ".png"; // Assume filenames match characters (e.g., '/.png', '#.png').
        if (texture.loadFromFile(path)) {
            textures[object] = texture;
        } else {
            std::cerr << "Failed to load texture for " << object << " (" << path << ")\n";
        }
    }
    return textures;
}

//TODO ARC - move to resoruce manager and delete
void saveBoardToFile(const std::vector<std::vector<char>>& board, const std::string& filename) {
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "Failed to open " << filename << " for saving.\n";
        return;
    }

    for (const auto& row : board) {
        for (const auto& cell : row) {
            file << cell;
        }
        file << '\n'; // Newline for each row
    }

    std::cout << "Board saved to " << filename << "\n";
}

void createMap(){
// Initialize window
    int width, height;
    std::cout << "Enter width and height (on the same line)" << std::endl;
    std::cin >> width >> height;

    sf::RenderWindow window(sf::VideoMode(TILE_SIZE * width, TILE_SIZE * height + TOOLBAR_HEIGHT), "Bomberman Map Editor");

    // Load toolbar objects
    std::unordered_map<char, sf::Texture> toolbarTextures = loadToolbarObjects("./Toolbar.txt");
    if (toolbarTextures.empty()) {
        return;
    }

    // Toolbar setup
    std::vector<sf::Sprite> toolbarSprites;
    int index = 0;
    for (const auto& [object, texture] : toolbarTextures) {
        sf::Sprite sprite(texture);
        sprite.setPosition(index * TILE_SIZE, 0);
        toolbarSprites.push_back(sprite);
        index++;
    }

    // Add eraser button
    sf::RectangleShape eraserButton(sf::Vector2f(TILE_SIZE, TILE_SIZE));
    eraserButton.setFillColor(sf::Color::Red);
    eraserButton.setPosition(index * TILE_SIZE, 0);
    index++;

    // Add delete-all button
    sf::RectangleShape deleteAllButton(sf::Vector2f(TILE_SIZE, TILE_SIZE));
    deleteAllButton.setFillColor(sf::Color::Blue);
    deleteAllButton.setPosition(index * TILE_SIZE, 0);

    // Map setup
    std::vector<std::vector<char>> board(height, std::vector<char>(width, ' '));
    sf::RectangleShape grid[TILE_SIZE][TILE_SIZE];
    std::vector<std::vector<sf::Sprite>> mapSprites(height, std::vector<sf::Sprite>(width));


    // Add save button setup
    sf::RectangleShape saveButton(sf::Vector2f(TILE_SIZE, TILE_SIZE));
    saveButton.setFillColor(sf::Color::Green);
    saveButton.setPosition((index + 1) * TILE_SIZE, 0);


    // Current tool
    char currentTool = ' ';
    bool rPlaced = false;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            // Handle mouse clicks
            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2i mousePos = sf::Mouse::getPosition(window);
                int x = mousePos.x / TILE_SIZE;
                int y = (mousePos.y - TOOLBAR_HEIGHT) / TILE_SIZE;

                // Toolbar clicks
                if (mousePos.y < TOOLBAR_HEIGHT) {
                    if (x < toolbarSprites.size()) {
                        currentTool = toolbarSprites[x].getTexture() == &toolbarTextures['/'] ? '/' :
                        toolbarSprites[x].getTexture() == &toolbarTextures['#'] ? '#' :
                        toolbarSprites[x].getTexture() == &toolbarTextures['!'] ? '!' :
                        toolbarSprites[x].getTexture() == &toolbarTextures['@'] ? '@' :
                        toolbarSprites[x].getTexture() == &toolbarTextures['D'] ? 'D' : ' ';
                    } else if (x == toolbarSprites.size()) { // Eraser button
                        currentTool = 'E'; // Select eraser tool
                    } else if (x == toolbarSprites.size() + 1) { // Delete all button
                        board = std::vector<std::vector<char>>(height, std::vector<char>(width, ' '));
                        rPlaced = false;
                        for (int i = 0; i < height; i++) {
                            for (int j = 0; j < width; j++) {
                                mapSprites[i][j].setTexture(sf::Texture()); // Clear all sprites
                            }
                        }
                    } else if (x == toolbarSprites.size() + 2)  // Save button
                        saveBoardToFile(board, "Board.txt");
                }
                // Map clicks
                else if (mousePos.y >= TOOLBAR_HEIGHT) {
                    if (currentTool == 'E') { // Eraser tool
                        if (board[y][x] == '/') {
                            rPlaced = false; // Allow r to be placed again
                        }
                        board[y][x] = ' ';
                        mapSprites[y][x].setTexture(sf::Texture());
                    } else if (currentTool != ' ') { // Place object
                        if (currentTool == '/' && rPlaced) {
                            continue; // Prevent placing more than one r
                        }
                        if (currentTool == '/') {
                            rPlaced = true;
                        }
                        board[y][x] = currentTool;
                        mapSprites[y][x].setTexture(toolbarTextures[currentTool]);
                        mapSprites[y][x].setPosition(x * TILE_SIZE, y * TILE_SIZE + TOOLBAR_HEIGHT);
                    }
                }
            }
        }

        // Drawing
        window.clear(sf::Color::White);

        // Draw toolbar
        for (const auto& sprite : toolbarSprites) {
            window.draw(sprite);
        }
        window.draw(eraserButton);
        window.draw(deleteAllButton);
        window.draw(saveButton);

        // Draw grid
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                if (board[i][j] != ' ') {
                    window.draw(mapSprites[i][j]);
                }
                sf::RectangleShape cell(sf::Vector2f(TILE_SIZE - 1, TILE_SIZE - 1));
                cell.setPosition(j * TILE_SIZE, i * TILE_SIZE + TOOLBAR_HEIGHT);
                cell.setFillColor(sf::Color::Transparent);
                cell.setOutlineColor(sf::Color::Black);
                cell.setOutlineThickness(1);
                window.draw(cell);
            }
        }

        window.display();
    }

}


void Game::loadObjectsFromMap() {
    staticObjects.clear();
    enemies.clear();

    const auto& grid = currentMap->getGrid();
    for (int i = 0; i < currentMap->getHeight(); ++i) {
        for (int j = 0; j < currentMap->getWidth(); ++j) {
            char tile = grid[i][j];

            switch (tile) {
                case '#': // Wall
                    staticObjects.push_back(new Wall(i, j, '#'));
                    break;
                case 'D': // Door
                    staticObjects.push_back(new Door(i, j));
                    break;
                case '@': // Destructible Wall
                    staticObjects.push_back(new Wall(i, j, '@'));
                    break;
                case '!': // Enemy
                    enemies.push_back(Enemy(i, j));
                    break;
                case 'g': //gift
                    srand(time(0));
                    int type = rand() % 4;
                    type = 0;
                    switch(type) {
                        case 0:
                            gifts.push_back(new FreezeEnemy(i, j, type));  
                            break;
                        case 1:
                            gifts.push_back(new AddLives(i, j, type));  
                            break;
                        case 2:
                            gifts.push_back(new AddTime(i, j, type));  
                            break;
                        case 3:
                            gifts.push_back(new RemoveEnemy(i, j, type));  
                            break;
                        default:
                            break;
                    }
            }
        }
    }
}





int countFilesInDirectory(const std::string& path) {
    int fileCount = 0;

    try {
        for (const auto& entry : fs::directory_iterator(path)) {
            if (fs::is_regular_file(entry.status())) {  // Check if it's a regular file
                ++fileCount;
            }
        }
    } catch (const fs::filesystem_error& e) {
        std::cerr << "Error accessing directory: " << e.what() << std::endl;
    }

    return fileCount;
}



Game::~Game() {
    if (player) {
        delete player;
        player = nullptr;
    }

    if (currentMap) {
        delete currentMap;
        currentMap = nullptr;
    }

    for (Gift* gift : gifts) 
        delete gift;

    gifts.clear();


    for (StaticObject* obj : staticObjects) 
        delete obj;
    
    staticObjects.clear();
}
