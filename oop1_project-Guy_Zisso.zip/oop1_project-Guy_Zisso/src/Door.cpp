#include "Door.h"
#include "macros.h"

#include <iostream> // delete todo arc

Door::Door() {}
Door::Door(int x, int y) : StaticObject(x, y) {}
