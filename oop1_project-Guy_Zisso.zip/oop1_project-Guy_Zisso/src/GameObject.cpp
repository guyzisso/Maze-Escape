#pragma once

#include "GameObject.h"

GameObject::GameObject() {}

GameObject::GameObject(float x, float y) : x(x), y(y) {}


float GameObject::getX() const { 
    return x; 
}

float GameObject::getY() const { 
    return y; 
}

