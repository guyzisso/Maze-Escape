#include "Wall.h"

Wall::Wall() : type('#') {}
Wall::Wall(int x, int y) : StaticObject(x, y), type('#') {}
Wall::Wall(int x, int y, char type) : StaticObject(x, y), type(type) {}
