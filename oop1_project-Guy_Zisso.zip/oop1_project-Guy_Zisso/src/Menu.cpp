#include "Menu.h"


Menu::Menu(sf::RenderWindow& window) : window(window) {
    loadButtons();

    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font\n";
    }

    livesText.setFont(font);
    livesText.setCharacterSize(24);
    livesText.setFillColor(sf::Color::White);
    livesText.setPosition(500, 10);  // Adjust position as needed
    livesText.setString("Lives: " + std::to_string(lives));
}
    

void Menu::loadButtons() {
    std::vector<std::string> filenames = {"help.jpeg", "newGame.jpeg", "exit.jpeg"};
    std::vector<sf::Vector2f> positions = {
        {TILE_SIZE, 0},  // Help
        {2*TILE_SIZE, 0},  // New Game
        {3*TILE_SIZE, 0}   // Exit
    };

    textures.resize(filenames.size());
    buttons.resize(filenames.size());

    for (size_t i = 0; i < filenames.size(); i++) {
        if (!textures[i].loadFromFile(filenames[i])) {
            std::cerr << "Failed to load " << filenames[i] << std::endl;
        } else {
            buttons[i].setTexture(textures[i]);
            buttons[i].setPosition(positions[i]);
        }
    }
}

void Menu::render(sf::RenderWindow& gameWindow) {
    for (const auto& button : buttons)
        gameWindow.draw(button);

    gameWindow.draw(livesText);
}


void Menu::handleClick(sf::Vector2f mousePos, Game& game) {
    for (size_t i = 0; i < buttons.size(); i++) {
        if (buttons[i].getGlobalBounds().contains(mousePos)) {
            if (i == 0) { openHelpWindow(); }
            else if (i == 1) { restartGame(game); }
            else if (i == 2) { window.close(); }
        }
    }
}

void Menu::openHelpWindow() {
    sf::RenderWindow helpWindow(sf::VideoMode(400, 300), "How to Play");
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Failed to load font\n";
        return;
    }

    sf::Text helpText("Use WASD to move, B to place a bomb.", font, 20);
    helpText.setPosition(20, 100);
    helpText.setFillColor(sf::Color::White);

    while (helpWindow.isOpen()) {
        sf::Event event;
        while (helpWindow.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                helpWindow.close();
        }

        helpWindow.clear(sf::Color::Black);
        helpWindow.draw(helpText);
        helpWindow.display();
    }
}

void Menu::restartGame(Game& game) {
    std::cout << "Restarting game..." << std::endl;
    game.restart();
}


void Menu::updateLives(int newLives) {
    lives = newLives;
    livesText.setString("Lives: " + std::to_string(lives));
}



// void Menu::render(sf::RenderWindow& window) {

//     std::vector<sf::Texture> menu; //0 - exit, 1 - help, 2 - new game
//     sf::Texture texture;
//     int i = 0;
//     std::string help = "help.png";
//     std::string newGame = "newGame.png";
//     std::string exit = "exit.png";
//     std::vector<std::string> options = {help, newGame, exit};
//     for (const auto& option : options){
//         if (texture.loadFromFile(option)) 
//             menu[i] = texture;
//         else 
//             std::cerr << "Failed to load texture for " << option << " (" << option << ")\n";
//         i++;
//     }

//     // Toolbar setup
//     std::vector<sf::Sprite> toolbarSprites;
//     int index = 0;
//     for (const auto& [object, texture] : toolbarTextures) {
//         sf::Sprite sprite(texture);
//         sprite.setPosition(index * TILE_SIZE, 0);
//         toolbarSprites.push_back(sprite);
//         index++;
//     }


// }