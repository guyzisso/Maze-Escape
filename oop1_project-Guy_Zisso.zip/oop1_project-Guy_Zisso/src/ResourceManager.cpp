#include "ResourceManager.h"


ResourceManager::ResourceManager() {}



void ResourceManager::saveBoardToFile(const std::vector<std::vector<char>>& board, const std::string& filename) {
    std::ofstream file(filename);
    if (!file) {
        std::cerr << "Failed to open " << filename << " for saving.\n";
        return;
    }

    for (const auto& row : board) {
        for (const auto& cell : row) {
            file << cell;
        }
        file << '\n'; // Newline for each row
    }

    std::cout << "Board saved to " << filename << "\n";
}



void ResourceManager::loadToolbarObjects(const std::string& filename) {
    textures.clear();  // Clear previous textures before loading new ones
    std::ifstream file(filename);

    if (!file) {
        std::cerr << "Failed to open " << filename << "\n";
        return;
    }

    char object;
    while (file >> object) {
        sf::Texture texture;
        std::string path = (object == '/') ? "./r.png" : "./" + std::string(1, object) + ".png";
        if (texture.loadFromFile(path)) {
            textures[object] = texture;
        } else {
            std::cerr << "Failed to load texture for " << object << " (" << path << ")\n";
        }
    }
}

const std::unordered_map<char, sf::Texture>& ResourceManager::getToolbarTextures() const {
    return textures;
}
