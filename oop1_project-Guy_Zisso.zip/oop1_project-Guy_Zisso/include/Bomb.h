#ifndef BOMB_H
#define BOMB_H
#include <SFML/Graphics.hpp>  // Include SFML graphics for the clock


class Bomb {
public:
    Bomb();
    Bomb(int timer);  // Constructor
    void activate(float x, float y);
    bool check();
    int getX() const;
    int getY() const;
    bool isActive() const;
    sf::Clock getClock() const;
    sf::Time getTimer() const;

private:
    int x, y;
    bool active;
    sf::Clock clock;
    sf::Time timer;
};

#endif  // Bomb_H
