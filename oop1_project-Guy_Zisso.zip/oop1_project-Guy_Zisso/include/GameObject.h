#pragma once

class GameObject {
public:
    GameObject();
    GameObject(float x, float y);

    // Pure virtual function to ensure all game objects implement a draw method
    // virtual void draw() = 0;

    // Getters for position
    float getX() const;
    float getY() const;

    virtual ~GameObject() = default;

protected:
    float x, y;  // Position variables, accessible by subclasses
};


