#pragma once
#include "Gift.h"
#include "Enemy.h"
#include <cstdlib>
#include <ctime>

class Enemy;

class RemoveEnemy : public Gift {
public:
    RemoveEnemy();
    RemoveEnemy(int x, int y, int type);
    void activate();
    void activate(std::vector<Enemy>& enemies);

};
