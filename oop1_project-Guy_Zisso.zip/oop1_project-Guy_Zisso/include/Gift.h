#ifndef GIFT_H
#define GIFT_H
#include <SFML/Graphics.hpp>  // Include SFML graphics for the clock
#include "StaticObject.h"
#include "macros.h"



class Gift : public StaticObject {
public:
    Gift();
    Gift(int x, int y, int type);  // Constructor

    virtual void activate() = 0;

    int getType() const;

protected:
    int type;
    
};

#endif  
