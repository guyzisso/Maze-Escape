#ifndef ENEMY_H
#define ENEMY_H

#include "Map.h"
#include "DynamicObject.h"


class Map;  // Forward declaration if you use Map in Player.cpp

class Enemy : public DynamicObject{
public:
    Enemy(int x, int y);
    void move();
    static std::vector<Enemy> setEnemies(const Map& currentMap); 

private:
    int prevX, prevY;  
    bool moveBack;      // Flag to indicate if the enemy should move back
};

#endif


