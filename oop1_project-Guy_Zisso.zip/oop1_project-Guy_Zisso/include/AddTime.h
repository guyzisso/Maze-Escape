#pragma once
#include "Gift.h"

class AddTime : public Gift {
public:
    AddTime();
    AddTime(int x, int y, int type);
    void activate() override;

};
