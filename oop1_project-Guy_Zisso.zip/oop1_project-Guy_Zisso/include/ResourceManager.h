#pragma once
#include "macros.h"
#include <unordered_map>
#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#include <fstream>


class ResourceManager {
public:
    ResourceManager();
    
    void loadToolbarObjects(const std::string& filename);
    const std::unordered_map<char, sf::Texture>& getToolbarTextures() const;
    void saveBoardToFile(const std::vector<std::vector<char>>& board, const std::string& filename);

private:
    std::unordered_map<char, sf::Texture> textures;  // Store textures as a member variable
};

