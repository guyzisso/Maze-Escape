#pragma once

const auto MAX_COL = 70;
const auto MAX_ROW = 50;


const auto LEVELS_PATH = "/levels/";


// Constants
const int TILE_SIZE = 50;
const int TOOLBAR_HEIGHT = TILE_SIZE;
const int MENU_HEIGHT = TILE_SIZE;

const int DEFAULT_WINDOW_WIDTH = 800;
const int DEFAULT_WINDOW_HEIGHT = 600;
const float SPEED = 70.0f;
const int LIVES = 3;