#pragma once
#include "GameObject.h"

class StaticObject : public GameObject {
public:
    StaticObject();
    StaticObject(int x, int y);
    virtual ~StaticObject() = default;  // Ensure a virtual destructor
};
