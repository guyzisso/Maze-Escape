#pragma once

#include "GameObject.h"

class DynamicObject : public GameObject {
    public:
        DynamicObject();
        
        DynamicObject(float x, float y);

        void setPosition(float x, float y);
        
        virtual ~DynamicObject() = default;

};


