#pragma once
#include "Gift.h"

class AddLives : public Gift {
public:
    AddLives();
    AddLives(int x, int y, int type);
    void activate();
};
