#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <filesystem>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <cstdlib>
#include <ctime>


#include "macros.h"
#include "Map.h"
#include "Player.h"
#include "Enemy.h"
#include "Menu.h"
#include "Gift.h"
#include "RemoveEnemy.h"
#include "FreezeEnemy.h"
#include "AddLives.h"
#include "AddTime.h"
#include "Wall.h"
#include "Door.h"

// #include "StaticObject.h"

class Map;
class Enemy;
class Player;
class Gift;

class Game {
public:
    Game();
    void run();
    void restart();
    void loadObjectsFromMap(); // New method to initialize objects from the map
    bool right = false, down = false;

    ~Game();
        

private:
    int currentLevel;
    bool restartGame = false;
    int numlevels;
    Player* player;
    std::vector<Enemy> enemies;
    std::vector<StaticObject*> staticObjects;
    std::vector<Gift*> gifts;

    Map *currentMap;
    sf::RenderWindow window;  // SFML window for the game
    sf::Clock mapUpdateClock;  // Clock for map updates
    sf::Clock clock;  // Clock for map updates
    float mapUpdateDelay = 0.1f;  // Time in seconds for map updates

    //TODO ARC - delete from Map and move here. 
    sf::Clock enemyMoveClock; // Clock to track time for enemy movement
    float moveDelay = 0.5f; // Time in seconds between enemy moves

    bool loadLevel(int lvl);
    void handleInput(sf::Event event);

};


#endif // GAME_H
