#pragma once
#include "macros.h"
#include <SFML/Graphics.hpp>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include "Game.h"

class Game;


class Menu {
public:
    Menu(sf::RenderWindow& window);
    
    void render(sf::RenderWindow& gameWindow);
    void handleClick(sf::Vector2f mousePos, Game& game);
    void updateLives(int newLives);
    
private:
    sf::RenderWindow& window;
    std::vector<sf::Sprite> buttons;
    std::vector<sf::Texture> textures;

    sf::Text livesText;
    sf::Font font;
    int lives = LIVES;
    
    void loadButtons();
    void openHelpWindow();
    void restartGame(Game& game);
};

   



