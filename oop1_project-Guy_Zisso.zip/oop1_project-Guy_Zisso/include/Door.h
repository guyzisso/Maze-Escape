#ifndef DOOR_H
#define DOOR_H
#include <SFML/Graphics.hpp>  
#include "StaticObject.h"

class Door : public StaticObject {
public:
    Door();
    Door(int x, int y);
};

#endif // DOOR_H
