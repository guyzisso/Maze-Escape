#ifndef PLAYER_H
#define PLAYER_H
#include <SFML/Graphics.hpp>
#include "macros.h"
#include "Bomb.h"
#include "Map.h"
#include "DynamicObject.h"

class Map;

class Player : public DynamicObject {
public:
    Player();
    Player(float x, float y);
    Player(float x, float y, int bombTimer);
    
    void move(int dx, int dy);
    void dropBomb();
    void update(float deltaTime, Map map, bool right, bool down); 
    void setVelocity(float vx, float vy);

    void addLife();
    void removeLife();
    int getLives() const;
        
    Bomb bomb;

private:
    int bombnum;
    sf::Vector2f velocity;
    int lives = LIVES;
};

#endif // PLAYER_H
    