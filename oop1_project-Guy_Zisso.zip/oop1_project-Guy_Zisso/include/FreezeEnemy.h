#ifndef FREEZEENEMY_H
#define FREEZEENEMY_H

#include "Gift.h"
#include <SFML/System/Clock.hpp>
#include <iostream>

class FreezeEnemy : public Gift {
public:
    FreezeEnemy();
    FreezeEnemy(int x, int y, int type);
    void activate() override;

    static bool frozen;  
    static sf::Clock freezeClock; 
};

#endif


