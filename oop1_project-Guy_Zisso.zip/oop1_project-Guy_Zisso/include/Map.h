#ifndef MAP_H
#define MAP_H

#include <vector>
#include <string>
#include <SFML/Graphics.hpp>  // For rendering the map with SFML
#include <filesystem>        // For constructing file paths
#include "Player.h"
#include "Enemy.h"
#include "Gift.h"
#include "Game.h"
#include "macros.h"

class Player;
class Enemy;
class Game;
class Gift;

// The Map class handles the game map, including rendering, validation, and updates.
class Map {
public:
    // Constructor
    Map();

    int getHeight() const;
    int getWidth() const;

    void loadLevel();
    bool loadLevel(int lvl);

    // Render the map to an SFML window
    void render(sf::RenderWindow& window, Player player);

    bool isValidMove(float x, float y, bool right, bool down) const;

    bool isDestructibleWall(int x, int y) const;

    void destroyWall(int x, int y);

    void updateMap(Player &player, std::vector<Enemy> &enemies, std::vector<Gift*> &gifts, Game &game);

    const std::vector<std::vector<char>>& getGrid() const;

    void printGrid();
    

private:
    // 2D grid representing the map layout
    std::vector<std::vector<char>> grid ;

    int width;
    int height;


};

#endif  // MAP_H


