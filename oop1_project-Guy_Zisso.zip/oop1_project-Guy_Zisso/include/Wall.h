#ifndef WALL_H
#define WALL_H
#include <SFML/Graphics.hpp>  // Include SFML graphics for the clock
#include "macros.h"
#include "StaticObject.h"

class Wall : public StaticObject{
public:
    Wall();
    Wall(int x, int y);
    Wall(int x, int y, char type);

private:
    char type;
};

#endif  

